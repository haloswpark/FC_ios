//
//  DataCenter.h
//  TableViewControllers
//
//  Created by Alchemist on 2016. 6. 13..
//  Copyright © 2016년 Alchemist. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *const keyWeatherCity = @"City";
static NSString *const keyWeatherDegree = @"Degree";

typedef NS_ENUM(NSInteger, SecondTableType) {
    SecondTableTypeFastcampus,
    SecondTableTypeWeather
};

typedef NS_ENUM(NSInteger, FastcampusType) {
    FastcampusTypeSchool,
    FastcampusTypeCamp,
    FastcampusTypeNone
};

typedef NS_ENUM(NSInteger, WeatherType) {
    WeatherTypeKorea,
    WeatherTypeInternational,
    WeatherTypeNone
};

@interface DataCenter : NSObject

+ (instancetype)defaultData;

@property (nonatomic, readonly, strong) NSArray *firstTableSectionHeaderTitles;
//@property (nonatomic, readonly, strong) NSArray *firstTableDataArrays;

- (NSArray *)firstTableDataForSection:(NSInteger)section;
- (NSArray *)secondTableDatasForType:(SecondTableType)type;
- (NSArray *)weatherDataForType:(WeatherType)type;
- (NSArray *)fastcampusDataForType:(FastcampusType)type;

@end
