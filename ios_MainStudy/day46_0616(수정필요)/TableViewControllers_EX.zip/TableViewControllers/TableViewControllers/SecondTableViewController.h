//
//  SecondTableViewController.h
//  TableViewControllers
//
//  Created by Alchemist on 2016. 6. 13..
//  Copyright © 2016년 Alchemist. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataCenter.h"

@interface SecondTableViewController : UITableViewController

@property (nonatomic) SecondTableType type;
@property (nonatomic) WeatherType weatherType;
@property (nonatomic) FastcampusType fastcampusType;

@end
