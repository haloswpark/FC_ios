//
//  DataCenter.m
//  TableViewControllers
//
//  Created by Alchemist on 2016. 6. 13..
//  Copyright © 2016년 Alchemist. All rights reserved.
//

#import "DataCenter.h"

@interface DataCenter()

@property (nonatomic, strong) NSArray *firstTableDatas;
@property (nonatomic, strong) NSArray *secondTableDatas;

@end

@implementation DataCenter

+ (instancetype)defaultData
{
    static DataCenter *dataCenter = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dataCenter = [[DataCenter alloc] init];
        dataCenter.firstTableDatas = @[@[@"School", @"Camp"], @[@"한국날씨", @"세계날씨"]];
        
        NSArray *schoolDatas = @[@"iOS", @"Android", @"Web", @"Front"];
        NSArray *campDatas = @[@"iOS 입문", @"iOS 초급", @"iOS 중급"];
        NSArray *fastcampusDatas = @[schoolDatas, campDatas];
        
        //키와 값으로 이루어진 딕셔너리의 배열을 생성
        NSArray *koreanWeatherDatas = @[@{keyWeatherCity:@"서울", keyWeatherDegree:@"36.5"},
                                        @{keyWeatherCity:@"대전", keyWeatherDegree:@"30.3"},
                                        @{keyWeatherCity:@"대구", keyWeatherDegree:@"38.1"},
                                        @{keyWeatherCity:@"부산", keyWeatherDegree:@"36.1"},
                                        @{keyWeatherCity:@"제주", keyWeatherDegree:@"29.5"}];
        NSArray *internationalWeatherDatas = @[@{keyWeatherCity:@"뉴욕", keyWeatherDegree:@"22.5"},
                                               @{keyWeatherCity:@"서울", keyWeatherDegree:@"30.3"},
                                               @{keyWeatherCity:@"도쿄", keyWeatherDegree:@"38.1"},
                                               @{keyWeatherCity:@"멜버른", keyWeatherDegree:@"15.1"},
                                               @{keyWeatherCity:@"타이페이", keyWeatherDegree:@"33.5"}];
        NSArray *weatherDatas = @[koreanWeatherDatas, internationalWeatherDatas];
        
        dataCenter.secondTableDatas = @[fastcampusDatas, weatherDatas];
        
    });
    
    return dataCenter;
}

- (NSArray *)firstTableDataForSection:(NSInteger)section {
    return self.firstTableDatas[section];
}

- (NSArray *)firstTableSectionHeaderTitles {
    return @[@"패스트캠퍼스 강좌", @"날씨"];
}

//타입에 따라 영역을 구분해 데이터 반환하는 메소드
- (NSArray *)secondTableDatasForType:(SecondTableType)type {
    return self.secondTableDatas[type];
}
//날씨 타입에 따라 세계/한국 날씨 반환
- (NSArray *)weatherDataForType:(WeatherType)type {
    return [self secondTableDatasForType:SecondTableTypeWeather][type];
}
//패캠 타입에 따라 스쿨/캠프 반환
- (NSArray *)fastcampusDataForType:(FastcampusType)type {
    return [self secondTableDatasForType:SecondTableTypeFastcampus][type];
}


@end
